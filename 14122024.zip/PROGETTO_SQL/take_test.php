<?php
session_start();
require 'config.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'student') {
    header("Location: index.php");
    exit();
}

$test_id = $_GET['id'];
$sql = "SELECT * FROM questions WHERE test_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $test_id);
$stmt->execute();
$questions = $stmt->get_result();
?>

<!DOCTYPE html>
<html>
<head>
    <title>Compila il Test</title>
    <link rel="stylesheet" href="css/style-create.css">
</head>
<body>
    <h1>Compila il Test</h1>
    
    <form method="POST" action="submit_test.php">
        <input type="hidden" name="test_id" value="<?= $test_id ?>">
        
        <?php while ($question = $questions->fetch_assoc()): ?>
            <div class="question-container">
                <h3><?= htmlspecialchars($question['question_text']) ?></h3>
                
                <?php if ($question['type'] === 'free_text'): ?>
                    <div class="answer-section">
                        <textarea 
                            name="answers[<?= $question['id'] ?>]" 
                            rows="4" 
                            cols="50" 
                            required
                            placeholder="Scrivi qui la tua risposta..."
                        ></textarea>
                    </div>
                
                <?php else: ?>
                    <div class="answer-section">
                        <?php
                        $sql_options = "SELECT * FROM options WHERE question_id = ?";
                        $stmt_options = $conn->prepare($sql_options);
                        $stmt_options->bind_param("i", $question['id']);
                        $stmt_options->execute();
                        $options = $stmt_options->get_result();
                        ?>
                        
                        <?php while ($option = $options->fetch_assoc()): ?>
                            <label class="radio-label">
                                <input 
                                    type="radio" 
                                    name="answers[<?= $question['id'] ?>]" 
                                    value="<?= htmlspecialchars($option['option_text']) ?>" 
                                    required
                                >
                                <span class="radio-text">
                                    <?= htmlspecialchars($option['option_text']) ?>
                                </span>
                            </label>
                        <?php endwhile; ?>
                    </div>
                <?php endif; ?>
            </div>
        <?php endwhile; ?>
        
        <button type="submit">Invia il test</button>
    </form>
</body>
</html>