<?php
// Avvia la sessione per gestire lo stato dell'utente
session_start();

// Include il file di configurazione per la connessione al database
require 'config.php';

// Controllo ruolo insegnante
if ($_SESSION['role'] !== 'teacher') {
    header("Location: dashboard.php");
    exit();
}

// Verifica test ID
if (!isset($_GET['id'])) {
    die("Test ID non specificato.");
}
$test_id = $_GET['id'];

// Recupera i dettagli del test
$sql_test = "SELECT * FROM tests WHERE id = ?";
$stmt = $conn->prepare($sql_test);
$stmt->bind_param("i", $test_id);
$stmt->execute();
$test = $stmt->get_result()->fetch_assoc();

if (!$test) {
    die("Test non trovato.");
}

// Recupera le domande associate
$sql_questions = "SELECT q.*, GROUP_CONCAT(CONCAT(o.option_text, ':', o.is_correct, ':', o.id) SEPARATOR '||') as options 
                 FROM questions q 
                 LEFT JOIN options o ON q.id = o.question_id 
                 WHERE q.test_id = ? 
                 GROUP BY q.id";
$stmt = $conn->prepare($sql_questions);
$stmt->bind_param("i", $test_id);
$stmt->execute();
$questions = $stmt->get_result();

// Gestione dell'aggiunta di una nuova domanda
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['question_text'])) {
    $question_text = $_POST['question_text'];
    $question_type = $_POST['question_type'];

    // Inizia una transazione
    $conn->begin_transaction();

    try {
        // Inserisci la domanda
        $sql_add_question = "INSERT INTO questions (test_id, question_text, type) VALUES (?, ?, ?)";
        $stmt = $conn->prepare($sql_add_question);
        $stmt->bind_param("iss", $test_id, $question_text, $question_type);

        if (!$stmt->execute()) {
            throw new Exception("Errore nell'inserimento della domanda");
        }

        $question_id = $stmt->insert_id;

        // Gestisci le opzioni in base al tipo di domanda
        if ($question_type === 'multiple_choice') {
            $answers = isset($_POST['answers']) ? $_POST['answers'] : [];
            $correct_answers = isset($_POST['correct_answer']) ? $_POST['correct_answer'] : [];

            if (empty($answers)) {
                throw new Exception("Almeno una risposta deve essere fornita per una domanda a scelta multipla.");
            }

            $sql_add_option = "INSERT INTO options (question_id, option_text, is_correct) VALUES (?, ?, ?)";
            $stmt = $conn->prepare($sql_add_option);

            foreach ($answers as $index => $answer_text) {
                if (trim($answer_text) !== '') {  // Verifica che la risposta non sia vuota
                    $is_correct = in_array($index, $correct_answers) ? 1 : 0;
                    $stmt->bind_param("isi", $question_id, $answer_text, $is_correct);
                    if (!$stmt->execute()) {
                        throw new Exception("Errore nell'inserimento delle opzioni");
                    }
                }
            }
        }

        // Commit della transazione
        $conn->commit();
        header("Location: edit_test.php?id=$test_id");
        exit();
    } catch (Exception $e) {
        // Rollback in caso di errore
        $conn->rollback();
        die("Errore: " . $e->getMessage());
    }
}

// Funzione per eliminare un'opzione (questo viene gestito tramite GET per semplicità)
if (isset($_GET['delete_option_id'])) {
    $option_id = $_GET['delete_option_id'];
    $sql_delete_option = "DELETE FROM options WHERE id = ?";
    $stmt = $conn->prepare($sql_delete_option);
    $stmt->bind_param("i", $option_id);
    $stmt->execute();
    header("Location: edit_test.php?id=$test_id");
    exit();
}
?>

<!DOCTYPE html>
<html>

<head>
    <title>Modifica Test</title>
    <link rel="stylesheet" href="css/style-edit.css">

</head>

<body>
    <h1>Modifica Test: <?= htmlspecialchars($test['title']) ?></h1>

    <!-- Form per aggiungere una nuova domanda -->
    <form method="POST" action="" id="questionForm">
        <h3>Aggiungi una Domanda</h3>

        <div class="form-group">
            <label>Domanda:</label>
            <textarea name="question_text" required class="form-control"></textarea>
        </div>

        <div class="form-group">
            <label>Tipo di Domanda:</label>
            <select name="question_type" id="question_type" required onchange="toggleAnswers()">
                <option value="free_text">Domanda a Testo Libero</option>
                <option value="multiple_choice">Domanda a Scelta Multipla</option>
            </select>
        </div>

        <div id="answers-container" style="display: none;">
            <label>Risposte:</label>
            <div id="answers-list">
                <div class="answer-row">
                    <input type="text" name="answers[0]" placeholder="Risposta 1">
                    <input type="checkbox" name="correct_answer[]" value="0"> Corretta
                </div>
                <div class="answer-row">
                    <input type="text" name="answers[1]" placeholder="Risposta 2">
                    <input type="checkbox" name="correct_answer[]" value="1"> Corretta
                </div>
            </div>
            <button type="button" onclick="addAnswer()" class="generali">Aggiungi Risposta</button>
        </div>

        <button type="submit" class="generali">Salva Domanda</button>
    </form>

    <!-- Lista delle domande esistenti -->
    <h3>Domande esistenti:</h3>
    <div id="questions-list">
        <?php while ($question = $questions->fetch_assoc()): ?>
            <div class="question-box">
                <h4>
                    <?= htmlspecialchars($question['question_text']) ?>
                    <span class="question-type-badge">
                        <?= $question['type'] === 'multiple_choice' ? 'Scelta Multipla' : 'Testo Libero' ?>
                    </span>
                </h4>

                <?php if ($question['type'] === 'multiple_choice' && $question['options']): ?>
                    <div class="options-list">
                        <?php
                        $options = explode('||', $question['options']);
                        foreach ($options as $option) {
                            list($text, $is_correct, $option_id) = explode(':', $option);
                            echo '<div class="option-item ' . ($is_correct ? 'correct-option' : '') . '">';
                            echo '- ' . htmlspecialchars($text);
                            if ($is_correct) echo ' ✓';
                            echo ' <a href="edit_test.php?id=' . $test_id . '&delete_option_id=' . $option_id . '" class="delete-button" onclick="return confirm(\'Sei sicuro di voler eliminare questa opzione?\')">Elimina</a>';
                            echo '</div>';
                        }
                        ?>
                    </div>
                <?php endif; ?>

                <div class="question-actions">
                    <a href="delete_question.php?id=<?= $question['id'] ?>&test_id=<?= $test_id ?>"
                        onclick="return confirm('Sei sicuro di voler eliminare questa domanda?')" class="elimina">
                        Elimina
                    </a>
                </div>
            </div>
        <?php endwhile; ?>
    </div>

    <form action="dashboard.php">
        <button type="submit" class="generali">Torna alla Dashboard</button>
    </form>

    <script>
        let answerCount = 2;

        function toggleAnswers() {
            const questionType = document.getElementById('question_type').value;
            const answersContainer = document.getElementById('answers-container');

            // Rimuove la parte di risposta per domande a testo libero
            if (questionType === 'multiple_choice') {
                answersContainer.style.display = 'block';
            } else {
                answersContainer.style.display = 'none';
            }
        }

        function addAnswer() {
            const container = document.getElementById('answers-list');
            const newAnswer = document.createElement('div');
            newAnswer.className = 'answer-row';
            newAnswer.innerHTML = `
                <input type="text" name="answers[${answerCount}]" placeholder="Risposta ${answerCount + 1}" required>
                <input type="checkbox" name="correct_answer[]" value="${answerCount}" > Corretta
            `;
            container.appendChild(newAnswer);
            answerCount++;
        }

        document.addEventListener('DOMContentLoaded', function() {
            toggleAnswers();
        });
    </script>

</body>

</html>