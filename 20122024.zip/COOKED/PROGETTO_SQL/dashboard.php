<?php
session_start();
require 'config.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit();
}

$user_id = $_SESSION['user_id'];
$role = $_SESSION['role'];

if ($role === 'student') {
    $sql_student_class = "SELECT class FROM utenti WHERE id = ?";
    $stmt = $conn->prepare($sql_student_class);
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows === 1) {
        $student = $result->fetch_assoc();
        $student_class = $student['class'];

        $sql_class_tests = "SELECT t.* FROM tests t JOIN test_sessions ts ON t.id = ts.test_id WHERE ts.class = ?";
        $stmt = $conn->prepare($sql_class_tests);
        $stmt->bind_param("s", $student_class);
        $stmt->execute();
        $tests = $stmt->get_result();
    } else {
        die("Errore nel recupero della classe dello studente.");
    }
}

if ($role === 'teacher') {
    $sql_tests = "SELECT * FROM tests WHERE teacher_id = ?";
    $stmt = $conn->prepare($sql_tests);
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $tests = $stmt->get_result();
}

if ($role === 'admin') {
    $sql_teachers = "SELECT id, name AS nome, surname AS cognome, login FROM utenti WHERE role = 'teacher'";
    $result_teachers = $conn->query($sql_teachers);

    $sql_students = "SELECT id, name AS nome, surname AS cognome, login, class FROM utenti WHERE role = 'student'";
    $result_students = $conn->query($sql_students);
}
?>
<!DOCTYPE html>
<html lang="it">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
    <link rel="stylesheet" href="css/style-dashboard.css">
    <link rel="icon" type="image/png" href="Foto/icon.png">
</head>

<body>
    <div class="container">
        <?php if ($role === 'student'): ?>
            <h1>Benvenuto nella Dashboard Studente</h1>
            <h2>Test Disponibili</h2>
            <?php if ($tests->num_rows > 0): ?>
                <ul>
                    <?php while ($test = $tests->fetch_assoc()): ?>
                        <li>
                            <?= htmlspecialchars($test['title']) ?>
                            <a href="take_test.php?id=<?= $test['id'] ?>" class="create-test">Inizia</a>
                        </li>
                    <?php endwhile; ?>
                </ul>
            <?php else: ?>
                <p>Nessun test disponibile per la tua classe.</p>
            <?php endif; ?>
        <?php elseif ($role === 'teacher'): ?>
            <h1>Dashboard Insegnante</h1>
            <h2>Gestione Test</h2>
            <a href="create_test.php" class="create-test">Crea un nuovo test</a>
            <ul>
                <?php while ($test = $tests->fetch_assoc()): ?>
                    <li>
                        <?= htmlspecialchars($test['title']) ?>
                        <a href="edit_test.php?id=<?= $test['id'] ?>">Modifica</a>
                        <a href="delete_test.php?id=<?= $test['id'] ?>">Elimina</a>
                    </li>
                <?php endwhile; ?>
            </ul>
        <?php elseif ($role === 'admin'): ?>
            <h1>Dashboard Amministratore</h1>
            <h2>Gestione Utenti</h2>
            <h3>Lista Professori</h3>
            <?php if ($result_teachers && $result_teachers->num_rows > 0): ?>
                <table class="teacher-section">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Nome</th>
                            <th>Cognome</th>
                            <th>Login</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while ($teacher = $result_teachers->fetch_assoc()): ?>
                            <tr>
                                <td><?= htmlspecialchars($teacher['id']) ?></td>
                                <td><?= htmlspecialchars($teacher['nome']) ?></td>
                                <td><?= htmlspecialchars($teacher['cognome']) ?></td>
                                <td><?= htmlspecialchars($teacher['login']) ?></td>
                            </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            <?php else: ?>
                <p>Nessun professore registrato.</p>
            <?php endif; ?>
            <h3>Lista Studenti</h3>
            <?php if ($result_students && $result_students->num_rows > 0): ?>
                <table class="student-section">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Nome</th>
                            <th>Cognome</th>
                            <th>Login</th>
                            <th>Classe</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while ($student = $result_students->fetch_assoc()): ?>
                            <tr>
                                <td><?= htmlspecialchars($student['id']) ?></td>
                                <td><?= htmlspecialchars($student['nome']) ?></td>
                                <td><?= htmlspecialchars($student['cognome']) ?></td>
                                <td><?= htmlspecialchars($student['login']) ?></td>
                                <td><?= htmlspecialchars($student['class']) ?></td>
                            </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            <?php else: ?>
                <p>Nessuno studente registrato.</p>
            <?php endif; ?>
        <?php endif; ?>

        <form action="logout.php" method="POST">
            <button type="submit" class="logout">Logout</button>
        </form>
    </div>

</body>

</html>