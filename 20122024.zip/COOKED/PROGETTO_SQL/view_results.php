<?php
// Avvia la sessione per mantenere lo stato dell'utente.
session_start();

// Include il file di configurazione per la connessione al database.
require 'config.php';

// Controllo di accesso.
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'student') {
    header("Location: index.php");
    exit();
}

// Recupera l'ID dello studente dalla sessione.
$student_id = $_SESSION['user_id'];

// Query per ottenere i risultati dello studente.
$sql_results = "
    SELECT 
        t.title AS test_title, 
        q.question_text,        
        r.answer,               
        r.is_correct,        
        o.option_text AS correct_answer, 
        q.type AS question_type 
    FROM test_results r
    JOIN questions q ON r.question_id = q.id 
    JOIN tests t ON q.test_id = t.id         
    LEFT JOIN options o ON q.id = o.question_id AND o.is_correct = 1 
    WHERE r.student_id = ?                     
    ORDER BY t.title, q.id";

// Prepara ed esegue la query.
$stmt = $conn->prepare($sql_results);
$stmt->bind_param("i", $student_id);
$stmt->execute();
$results = $stmt->get_result();
?>

<!DOCTYPE html>
<html lang="it">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Risultati</title>
    <link rel="stylesheet" href="css/style-result.css"> <!-- Collegamento al file CSS -->
</head>
<body>
    <h1>I tuoi risultati</h1>

    <?php
    $current_test = ""; // Per separare i risultati per test.

    while ($row = $results->fetch_assoc()):
        if ($current_test != $row['test_title']):
            if ($current_test != ""): ?>
                </div> <!-- Fine del contenitore del test -->
            <?php endif; ?>

            <div class="test-container">
                <h2><?= htmlspecialchars($row['test_title']) ?></h2>
            <?php
            $current_test = $row['test_title'];
        endif;

        // Determina la classe CSS in base allo stato della risposta.
        if ($row['question_type'] === 'free_text') {
            $status_class = 'pending';
        } else {
            $status_class = $row['is_correct'] ? 'correct' : 'incorrect';
        }
    ?>

        <div class="question-container <?= $status_class ?>">
            <p><strong>Domanda:</strong> <?= htmlspecialchars($row['question_text']) ?></p>
            <p><strong>La tua Risposta:</strong> <?= htmlspecialchars($row['answer']) ?></p>
            <p><strong>Risposta Corretta:</strong> <?= htmlspecialchars($row['correct_answer']) ?></p>
            <p><strong>Corretta:</strong> 
                <?php 
                if ($row['question_type'] === 'free_text') {
                    echo "<span class='pending'>Da validare</span>";
                } elseif ($row['is_correct']) {
                    echo "Sì";
                } else {
                    echo "No";
                }
                ?>
            </p>
        </div>

    <?php endwhile; ?>
    </div> <!-- Fine dell'ultimo contenitore del test -->

    <!-- Pulsante per tornare indietro -->
    <button onclick="history.go(-2);">Torna indietro</button>
</body>
</html>
