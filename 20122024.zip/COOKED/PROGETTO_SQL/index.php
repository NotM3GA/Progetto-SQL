<?php
// Avvia una sessione per poter memorizzare variabili globali per l'utente.
session_start();

// Include il file di configurazione che probabilmente contiene i parametri di connessione al database.
require 'config.php';

// Controlla se il metodo della richiesta è POST (ossia se il form è stato inviato).
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Verifica che i campi 'login' e 'password' siano presenti nell'array $_POST.
    if (isset($_POST['login']) && isset($_POST['password'])) {
        $login = $_POST['login'];
        $password = $_POST['password'];

        // Prepara una query SQL per cercare l'utente corrispondente al login fornito.
        $sql = "SELECT * FROM utenti WHERE login = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("s", $login);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows === 1) {
            $user = $result->fetch_assoc();

            // Verifica la password.
            if (password_verify($password, $user['password'])) {
                $_SESSION['user_id'] = $user['id'];
                $_SESSION['role'] = $user['role'];
                $_SESSION['class'] = $user['class'];

                header("Location: dashboard.php");
                exit();
            }
        }
        $error = "Login o password errati.";
    } else {
        $error = "Per favore, compila tutti i campi.";
    }
}
?>

<!DOCTYPE html>
<html lang="it">

<head>
    <title>Login</title>
    <link rel="stylesheet" href="css/style-login.css">
    <link rel="icon" type="image/png" href="Foto/icon.png">


</head>

<body>
    <div class="login-container">
        <div class="login-header">
            <h1>🔒 LOGIN 🔒</h1>
        </div>
        <form method="POST" action="">
            <div class="form-group">
                <label for="login">Username:</label>
                <input type="text" id="login" name="login" placeholder="Inserisci il tuo username" required>
            </div>
            <div class="form-group">
                <label for="password">Password:</label>
                <input type="password" id="password" name="password" placeholder="Inserisci la tua password" required>
            </div>
            <button type="submit">Accedi</button>
        </form>

        <form action="register.php" class="register-form">
            <button type="submit" class="secondary" formnovalidate>Registrati</button>
        </form>

        <?php if (isset($error)) : ?>
            <p class="error-message"><?= htmlspecialchars($error); ?></p>
        <?php endif; ?>
    </div>
</body>

</html>