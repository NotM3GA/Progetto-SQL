-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Creato il: Dic 20, 2024 alle 16:23
-- Versione del server: 10.4.32-MariaDB
-- Versione PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `test_system`
--

-- --------------------------------------------------------

--
-- Struttura della tabella `options`
--

CREATE TABLE `options` (
  `id` int(11) NOT NULL,
  `question_id` int(11) DEFAULT NULL,
  `option_text` varchar(255) DEFAULT NULL,
  `is_correct` tinyint(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dump dei dati per la tabella `options`
--

INSERT INTO `options` (`id`, `question_id`, `option_text`, `is_correct`) VALUES
(75, 29, 'dipende dalla Netmask', 1),
(76, 29, '8', 0),
(77, 29, '24', 0),
(78, 29, '16', 0),
(79, 30, '32', 0),
(80, 30, '48', 1),
(81, 30, '64', 0),
(82, 30, '128', 0),
(83, 32, '172.16.1.2', 0),
(84, 32, '172.15.0.1', 1),
(85, 32, '172.16.255.254', 0),
(86, 32, 'Tutti gli indirizzi IP indicati', 0),
(92, 36, '6', 0),
(93, 36, '8', 1),
(94, 36, '9', 0),
(95, 37, 'X = 2', 1),
(96, 37, 'X = 3', 0),
(97, 37, 'X = 4', 0);

-- --------------------------------------------------------

--
-- Struttura della tabella `questions`
--

CREATE TABLE `questions` (
  `id` int(11) NOT NULL,
  `test_id` int(11) DEFAULT NULL,
  `question_text` text DEFAULT NULL,
  `type` enum('multiple_choice','free_text') DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dump dei dati per la tabella `questions`
--

INSERT INTO `questions` (`id`, `test_id`, `question_text`, `type`) VALUES
(29, 15, 'Quanti sono i bit che rappresentano la rete in un indirizzo IPv4?', 'multiple_choice'),
(30, 15, 'Da quanti bit è composto l’indirizzo fisico di una interfaccia Ethernet?', 'multiple_choice'),
(31, 15, 'Indicare i campi di un pacchetto IP:', 'free_text'),
(32, 15, 'Fissata una netmask a 16-bit quale dei seguenti indirizzi IP non appartiene alla rete\r\n172.16.0.0?', 'multiple_choice'),
(36, 16, 'Qual è il risultato di 5 + 3?', 'multiple_choice'),
(37, 16, 'Qual è il valore di x in 2x + 6 = 10?', 'multiple_choice');

-- --------------------------------------------------------

--
-- Struttura della tabella `tests`
--

CREATE TABLE `tests` (
  `id` int(11) NOT NULL,
  `title` varchar(100) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `teacher_id` int(11) DEFAULT NULL,
  `class` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dump dei dati per la tabella `tests`
--

INSERT INTO `tests` (`id`, `title`, `description`, `teacher_id`, `class`) VALUES
(15, 'Verifica di TPSI teoria', 'Verifica di teoria', 9, '5aii'),
(16, 'Matematica', 'VERIFICA MATEMATICA', 9, '5aii');

-- --------------------------------------------------------

--
-- Struttura della tabella `test_results`
--

CREATE TABLE `test_results` (
  `id` int(11) NOT NULL,
  `student_id` int(11) DEFAULT NULL,
  `question_id` int(11) DEFAULT NULL,
  `answer` text DEFAULT NULL,
  `is_correct` tinyint(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dump dei dati per la tabella `test_results`
--

INSERT INTO `test_results` (`id`, `student_id`, `question_id`, `answer`, `is_correct`) VALUES
(125, 10, 36, '8', 1),
(126, 10, 37, 'X = 2', 1),
(127, 10, 29, 'dipende dalla Netmask', 1),
(128, 10, 30, '48', 1),
(129, 10, 31, 'gg', 0),
(130, 10, 32, '172.15.0.1', 1);

-- --------------------------------------------------------

--
-- Struttura della tabella `test_sessions`
--

CREATE TABLE `test_sessions` (
  `id` int(11) NOT NULL,
  `test_id` int(11) DEFAULT NULL,
  `class` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dump dei dati per la tabella `test_sessions`
--

INSERT INTO `test_sessions` (`id`, `test_id`, `class`) VALUES
(7, 15, '5aii'),
(8, 16, '5aii');

-- --------------------------------------------------------

--
-- Struttura della tabella `utenti`
--

CREATE TABLE `utenti` (
  `id` int(11) NOT NULL,
  `name` varchar(50) DEFAULT NULL,
  `surname` varchar(50) DEFAULT NULL,
  `login` varchar(50) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `role` enum('student','teacher','admin') DEFAULT NULL,
  `class` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dump dei dati per la tabella `utenti`
--

INSERT INTO `utenti` (`id`, `name`, `surname`, `login`, `password`, `role`, `class`) VALUES
(9, 'fabio', 'biscaro', 'fabio', '$2y$10$1O.UpClTioDYfnN0mVjChu30TbqiR3AGCOsRvN6X.fVBuQzLmCApq', 'teacher', ''),
(10, 'alberto', 'zanatta', 'alberto', '$2y$10$BtUBrcOzHUgqxnOqiuN6ceaIWfx89SqboHWn.8PBw9DJO5r55vypW', 'student', '5AII'),
(14, 'Admin', 'admin', 'admin', '$2y$10$7p5PZTDrtQLPCcXBP2NQtOyb41y90DCqeplIrEskO7snPmiJbuB0i', 'admin', '');

--
-- Indici per le tabelle scaricate
--

--
-- Indici per le tabelle `options`
--
ALTER TABLE `options`
  ADD PRIMARY KEY (`id`),
  ADD KEY `question_id` (`question_id`);

--
-- Indici per le tabelle `questions`
--
ALTER TABLE `questions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `test_id` (`test_id`);

--
-- Indici per le tabelle `tests`
--
ALTER TABLE `tests`
  ADD PRIMARY KEY (`id`),
  ADD KEY `teacher_id` (`teacher_id`);

--
-- Indici per le tabelle `test_results`
--
ALTER TABLE `test_results`
  ADD PRIMARY KEY (`id`),
  ADD KEY `student_id` (`student_id`),
  ADD KEY `question_id` (`question_id`);

--
-- Indici per le tabelle `test_sessions`
--
ALTER TABLE `test_sessions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `test_id` (`test_id`);

--
-- Indici per le tabelle `utenti`
--
ALTER TABLE `utenti`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `login` (`login`);

--
-- AUTO_INCREMENT per le tabelle scaricate
--

--
-- AUTO_INCREMENT per la tabella `options`
--
ALTER TABLE `options`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=98;

--
-- AUTO_INCREMENT per la tabella `questions`
--
ALTER TABLE `questions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=38;

--
-- AUTO_INCREMENT per la tabella `tests`
--
ALTER TABLE `tests`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT per la tabella `test_results`
--
ALTER TABLE `test_results`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=131;

--
-- AUTO_INCREMENT per la tabella `test_sessions`
--
ALTER TABLE `test_sessions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT per la tabella `utenti`
--
ALTER TABLE `utenti`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- Limiti per le tabelle scaricate
--

--
-- Limiti per la tabella `options`
--
ALTER TABLE `options`
  ADD CONSTRAINT `options_ibfk_1` FOREIGN KEY (`question_id`) REFERENCES `questions` (`id`);

--
-- Limiti per la tabella `questions`
--
ALTER TABLE `questions`
  ADD CONSTRAINT `questions_ibfk_1` FOREIGN KEY (`test_id`) REFERENCES `tests` (`id`);

--
-- Limiti per la tabella `tests`
--
ALTER TABLE `tests`
  ADD CONSTRAINT `tests_ibfk_1` FOREIGN KEY (`teacher_id`) REFERENCES `utenti` (`id`);

--
-- Limiti per la tabella `test_results`
--
ALTER TABLE `test_results`
  ADD CONSTRAINT `test_results_ibfk_1` FOREIGN KEY (`student_id`) REFERENCES `utenti` (`id`),
  ADD CONSTRAINT `test_results_ibfk_2` FOREIGN KEY (`question_id`) REFERENCES `questions` (`id`) ON DELETE CASCADE;

--
-- Limiti per la tabella `test_sessions`
--
ALTER TABLE `test_sessions`
  ADD CONSTRAINT `test_sessions_ibfk_1` FOREIGN KEY (`test_id`) REFERENCES `tests` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
