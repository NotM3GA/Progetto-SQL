<?php
// Avvia la sessione per mantenere lo stato dell'utente.
session_start();

// Include il file di configurazione per la connessione al database.
require 'config.php';

// **Controllo di accesso**:
// Verifica che l'utente sia loggato e che il suo ruolo sia 'student'.
// Se non è loggato o non ha il ruolo di studente, reindirizza l'utente alla pagina di login (index.php).
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'student') {
    header("Location: index.php"); // Reindirizza alla pagina di login.
    exit(); // Termina l'esecuzione dello script per evitare di proseguire senza accesso.
}

// Recupera l'ID dello studente dalla sessione
$student_id = $_SESSION['user_id']; // Memorizza l'ID dello studente loggato.

// **Recupero dei risultati dello studente per ogni test**:
// Eseguiamo una query per recuperare i risultati separati per test, incluse le domande, risposte, e se sono corrette.
$sql_results = "
    SELECT 
        t.title AS test_title, 
        q.question_text,        
        r.answer,               
        r.is_correct,        
        o.option_text AS correct_answer, 
        q.type AS question_type 
    FROM test_results r
    JOIN questions q ON r.question_id = q.id 
    JOIN tests t ON q.test_id = t.id         
    LEFT JOIN options o ON q.id = o.question_id AND o.is_correct = 1 
    WHERE r.student_id = ?                     
    ORDER BY t.title, q.id";                   

    

// Prepara la query SQL per l'esecuzione
$stmt = $conn->prepare($sql_results);

// Collega l'ID dello studente come parametro della query (è un intero)
$stmt->bind_param("i", $student_id);

// Esegue la query SQL per ottenere i risultati
$stmt->execute();

// Ottiene il risultato della query e lo memorizza nella variabile `$results`
// Il risultato sarà un oggetto che contiene tutte le righe corrispondenti ai risultati dello studente.
$results = $stmt->get_result();
?>

<!DOCTYPE html>
<html>
<head>
    <title>Risultati</title>
    <link rel="stylesheet" href="css/style-result.css"> <!-- Include il foglio di stile per la pagina dei risultati -->
</head>
<body>
    <h1>I tuoi risultati</h1>

    <?php
    // Variabili per separare i risultati per test
    $current_test = ""; // Variabile che memorizza il test corrente per separare i risultati per ogni test

    // Ciclo per visualizzare i risultati
    while ($row = $results->fetch_assoc()):
        // Verifica se è cambiato il test (per separare i risultati)
        if ($current_test != $row['test_title']):
            if ($current_test != ""): ?>
                </table> <!-- Fine della tabella per il test precedente -->
            <?php endif; ?>
            <!-- Nuova tabella per un nuovo test -->
            <h2><?= htmlspecialchars($row['test_title']) ?></h2> <!-- Mostra il titolo del test -->
            <table border="1"> <!-- Crea una nuova tabella per il test -->
                <tr>
                    <th>Domanda</th>
                    <th>La tua Risposta</th>
                    <th>Risposta Corretta</th>
                    <th>Corretta</th>
                </tr>
            <?php 
            $current_test = $row['test_title']; // Memorizza il titolo del test corrente
        endif;
        ?>

        <!-- Righe della tabella con i risultati per ogni domanda -->
        <tr>
            <td><?= htmlspecialchars($row['question_text']) ?></td> <!-- Mostra il testo della domanda -->
            <td>
                <?= htmlspecialchars($row['answer']) ?> <!-- Mostra la risposta dello studente -->
                <?php if ($row['question_type'] === 'free_text' && $row['is_correct'] === NULL): ?>
                    <span style="color: orange;">(Da validare)</span> <!-- Mostra "Da validare" per domande a risposta aperta non ancora valutate -->
                <?php endif; ?>
            </td>
            <td><?= htmlspecialchars($row['correct_answer']) ?></td> <!-- Mostra la risposta corretta -->
            <td style="color: <?= ($row['is_correct'] === NULL) ? 'orange' : ($row['is_correct'] ? 'green' : 'red') ?>;">
                <?php 
                // Visualizza lo stato della risposta: "Da validare", "Sì" (corretta) o "No" (errata)
                if ($row['is_correct'] === NULL) {
                    echo "Da validare"; 
                } elseif ($row['is_correct']) {
                    echo "Sì"; 
                } else {
                    echo "No";
                }
                ?>
            </td>
        </tr>

    <?php endwhile; ?>

    </table> <!-- Fine dell'ultimo test -->

    <!-- Pulsante per tornare indietro -->
    <input type="button" value=" Torna indietro" onClick="history.go(-2);return true;" name="button"> <!-- Permette di tornare indietro di due pagine nella cronologia -->
</body>
</html>
